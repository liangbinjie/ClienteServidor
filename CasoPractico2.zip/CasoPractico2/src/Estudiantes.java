public class Estudiantes {
    private String nombre;
    private float peso;
    
    public Estudiantes() {
        this.nombre = "";
        this.peso = 0;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public float getPeso() {
        return peso;
    }

    public void setPeso(float peso) {
        this.peso = peso;
    }
    
    
    
}
